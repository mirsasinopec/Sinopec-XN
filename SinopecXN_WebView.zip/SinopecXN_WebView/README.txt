Sinopec XN — Android WebView APK
================================

Loads: https://employeesxn.netlify.app/

Build without Android Studio:
- You can upload this project to a GitHub repo and enable GitHub Actions (Android build) or
  open it in Android Studio later. Many online "Web2APK" services accept just the URL as well.

Local build (if you later install Android Studio):
1) Open folder in Android Studio.
2) Build > Build APK(s).
3) Output: app/build/outputs/apk/debug/app-debug.apk

Package details:
- Min SDK 24, Target SDK 34
- AppCompat + Material + SwipeRefreshLayout
- Pull-to-refresh, tel/whatsapp/mailto link handling, file downloads (DownloadManager), back navigation.